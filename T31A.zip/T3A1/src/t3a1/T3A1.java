package t3a1;
import java.util.Scanner;

public class T3A1 {
    
    public static void main (String[] args ){
        procesar();
    }
    
    public static void procesar (){
        Scanner scanner = new Scanner (System.in);
        Calificaciones calificaciones = new Calificaciones();
        
        System.out.println("Nombre: ");
        String nombre = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.println("Apellido Paterno: ");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.println("Apellido Materno: ");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.println ("Grupo: ");
        String grupo = scanner.nextLine();
        calificaciones.setGrupo(grupo);
        
        System.out.println("Carrera: ");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.println("Asignatura: ");
        String asignatura = scanner.nextLine();
        calificaciones.setNombreAsignatura(asignatura);
        
        System.out.println("Calificacion: ");
        int calificacion = scanner.nextInt();
        calificaciones.setCalificaciones(calificacion);
        
        System.out.println("Asignatura N.2: ");
        String asignatura2 = scanner.next();
        calificaciones.setNombreAsignatura2(asignatura2);
        
        System.out.println("2da Calificacion: ");
        int calificaciones2 = scanner.nextInt();
        calificaciones.setCalificaciones2(calificaciones2);
        
        
        double promedio=(calificacion + calificaciones2)/2;
        calificaciones.setPromedio(promedio);
        
        System.out.println(calificaciones.toString());
    
        
      }
    
}
